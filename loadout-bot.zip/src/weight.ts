import fs from 'fs';
import path from 'path';

const ITEMS_PATH = path.join(process.cwd(), 'data', 'items.json');

type ItemDB = Record<string, number>;

let itemDB: ItemDB | null = null;

function loadItems(): ItemDB {
  if (itemDB) return itemDB;
  if (!fs.existsSync(ITEMS_PATH)) return {};
  itemDB = JSON.parse(fs.readFileSync(ITEMS_PATH, 'utf8'));
  return itemDB!;
}

function massToKg(mass: number): number {
  return mass * 0.1 / 2.2046;
}

export function calculateWeight(loadout: string): number | null {
  const items = loadItems();
  if (Object.keys(items).length === 0) return null;

  try {
    const parsed = JSON.parse(loadout);
    const flat = JSON.stringify(parsed).match(/"([^"]+)"/g) ?? [];
    const classnames = flat.map((s: string) => s.replace(/"/g, ''));

    let total = 0;
    for (const classname of classnames) {
      if (items[classname]) total += massToKg(items[classname]);
    }
    return Math.round(total * 100) / 100;
  } catch {
    return null;
  }
}
